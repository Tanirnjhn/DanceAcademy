package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Choreographer;
import com.cg.service.ChoreographerService;

@CrossOrigin(value="http://localhost:4200")
@RequestMapping(value="/api/dance")
@RestController
public class ChoreographerController {

	@Autowired
	private ChoreographerService choreographerService;

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@PostMapping(value = "/addChoreographer")
	public Choreographer postChoreographer(@RequestBody Choreographer choreographer) {
		System.out.println(choreographer);
		Choreographer _choreographer = choreographerService.addChoreographer(choreographer);
		LOG.info("Saving Choreographer  Details...");
		return _choreographer;
	}

	@GetMapping(value="/getChByLocation")
	public List<Choreographer> getChoreographer(@RequestParam("location") String location)
	{
		List<Choreographer> list= new ArrayList<Choreographer>();
		list=choreographerService.getChoreographerByLocation(location);

		return list;
	}
	
	@DeleteMapping(value="/deleteChoreographer")
	public void deleteChoreographer(@RequestParam("choreographerId") int choreographerId) {
		//choreographer _choreographer = choreographerService.getchoreographerById(choreographerId);
		System.out.println("hitting backend"+choreographerId);
		choreographerService.deleteChoreographer(choreographerId);

		LOG.info("Deleted choreographer successfully...");
	}
	
	@GetMapping(value="/getChoreographerList")
	public List<Choreographer> getAllChoreographer()
	{
		List<Choreographer> choreographerList= new ArrayList<Choreographer>();
		choreographerList=choreographerService.getAllChoreographer();
		return choreographerList;
	}



	@GetMapping(value="/getChByName")
	public List<Choreographer> getChByName(@RequestParam("chName")String chName)
	{
		System.out.println(chName);
		List<Choreographer> c= new ArrayList<Choreographer>();
		c= choreographerService.getChoreographerByName(chName);
		System.out.println("gettttttingggg"+c);
		return c;
	}

	
	@PostMapping(value="/updateCount")
	public Choreographer updateIntake(@RequestBody Choreographer choreographer)
	{
		System.out.println("................"+choreographer);
		Choreographer _choreographer = choreographerService.addChoreographer(choreographer);
		LOG.info("Saving Choreographer  Details...");
		return _choreographer;
	}
}
