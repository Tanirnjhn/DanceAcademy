package com.cg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.beans.Choreographer;

@Repository
public interface ChoreographerDao extends JpaRepository<Choreographer, Integer> {
//	@Query(value = "SELECT * FROM choreographer s WHERE s.username = ?1 AND s.password = ?2", nativeQuery = true)
//	public Choreographer validateChoreographer(String username, String password);
	
	@Query(value="SELECT * FROM choreographer c where c.ch_location=?1 AND c.ch_intake > 0",nativeQuery=true)
	public List<Choreographer> getChoreographerByLocation(String location);

//	@Query(value="SELECT * FROM choreographer s where s.ch_name=?1")
//	public Choreographer getChByName(String chrName);

	
	@Transactional
	  
	  @Query(value =
	  "UPDATE choreographer s SET s.ch_intake = s.ch_intake-1 where s.ch_name= ?1",nativeQuery = true)
	@Modifying
	public int updateChCount(String chName);
}
