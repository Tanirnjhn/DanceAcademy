package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

@Entity
@Table(name = "Candidate")
public class Candidate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull
	@Column(name = "candidate_id")
	private int candidateId;
	@NotNull
	@Column(name = "first_name")
	private String firstname;
	@NotNull
	@Column(name = "last_name")
	private String lastname;
	@NotNull
	@Column(name = "email")
	private String email;
	@NotNull
	@Column(name = "phone")
	private String phone;
	
	@Column(name = "location")
	@NotNull
	private String location;
	@NotNull
	@Column(name = "danceStyle")
	private String danceStyle;
	@NotNull
	@Column(name = "gender")
	private String gender;
	@NotNull
	@Column(name = "chrName")
	private String chrName;

	public Candidate() {
		// TODO Auto-generated constructor stub
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDanceStyle() {
		return danceStyle;
	}

	public void setDanceStyle(String danceStyle) {
		this.danceStyle = danceStyle;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	

	public String getChrName() {
		return chrName;
	}

	public void setChrName(String chrName) {
		this.chrName = chrName;
	}

	@Override
	public String toString() {
		return "Candidate [candidateId=" + candidateId + ", firstname=" + firstname + ", lastname=" + lastname
				+ ", email=" + email + ", phone=" + phone + ", location=" + location + ", danceStyle=" + danceStyle
				+ ", gender=" + gender + ", chrName=" + chrName + "]";
	}

}
