package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Candidate;
import com.cg.dao.CandidateDao;

@Service
public class CandidateServiceImpl{

	@Autowired
	CandidateDao candidateDao;
	
	public Candidate addCandidate(Candidate candidate) {
		return candidateDao.save(candidate);
	}

	public void deleteCandidate(int candidateId) {
		candidateDao.deleteById(candidateId);
	}
//	@Override
//	public boolean signUp(Candidate candidate) {
//		// TODO Auto-generated method stub
//		System.out.println("Service");
//		return iCandidateDao.signUp(candidate);
//	}
//	
//	 @Override
//	    public void sessionCreated(HttpSessionEvent event) {
//	        System.out.println("session created");
//	        event.getSession().setMaxInactiveInterval(15);
//	    }
//
//	    @Override
//	    public void sessionDestroyed(HttpSessionEvent event) {
//	       System.out.println("session destroyed");
//	    }

	public List<Candidate> getAllCandidate() {
		// TODO Auto-generated method stub
		return candidateDao.findAll();
	}

}
