package com.cg.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Candidate;
import com.cg.beans.Choreographer;
import com.cg.service.CandidateServiceImpl;
import com.cg.service.ChoreographerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value = "/api/dance")
public class CandidateController {

	@Autowired
	CandidateServiceImpl candidateService;

	@Autowired
	private ChoreographerService choreographerService;
	
	public String chname;

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@PostMapping(value = "/addCandidate")
	public Candidate postCandidate(@RequestBody Candidate candidate,HttpSession session) {
		System.out.println(candidate);
		Candidate _candidate = new Candidate();
		_candidate=	candidateService.addCandidate(candidate);
		chname=_candidate.getChrName();
		LOG.info("Saving Candidate  Details..."+_candidate);
		return _candidate;
		
	}
	
	@PutMapping(value="/updateCount")
//	public void updateCount(@RequestParam("chName")String chName,HttpSession session)
	public void updateCount(HttpSession session)
	{
		
//		System.out.println("chname"+chName);
//		Choreographer ch= new Choreographer();
//		ch=choreographerService.getChByName(chName);
//		int count=ch.getIntake();
//		count=count-1;
//		ch.setIntake(count);
//		Choreographer c=choreographerService.addChoreographer(ch);
//		return c;
//		System.out.println("Hellochname "+chName);
		String temp= chname;
		System.out.println("Hellochname "+temp);
		choreographerService.updateChCount(temp);
//		int val=choreographerService.updateChCount(chName);
//		return val;
	}

	
	
	
	
	
//	public ICandidateService getiCandidateService() {
//		return iCandidateService;
//	}
//
//	public void setiCandidateService(ICandidateService iCandidateService) {
//		this.iCandidateService = iCandidateService;
//	}
//
//	@RequestMapping(method = RequestMethod.POST, value = "/signup", consumes = "application/json")
//	public boolean signUp(@RequestBody Candidate candidate) {
//		System.out.println("Controller");
//		return iCandidateService.signUp(candidate);
//	}

}
