package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Choreographer;
import com.cg.service.ChoreographerService;

@CrossOrigin(value="http://localhost:4200")
@RequestMapping(value="/api/dance")
@RestController
public class ChoreographerController {

	@Autowired
	private ChoreographerService choreographerService;

	private final Logger LOG = LoggerFactory.getLogger(getClass());

	@PostMapping(value = "/addChoreographer")
	public Choreographer postChoreographer(@RequestBody Choreographer choreographer) {
		System.out.println(choreographer);
		Choreographer _choreographer = choreographerService.addChoreographer(choreographer);
		LOG.info("Saving Choreographer  Details...");
		return _choreographer;
	}


	//
	//	@GetMapping(value = "/getChoreographerDetail")
	//	public List<Choreographer> getAllChoreographerList() {
	//		List<Choreographer> ChoreographerList = choreographerService.getAllChoreographer();
	//		System.out.println("flight_list" + ChoreographerList);
	//		LOG.info(" getting Choreographer  Details...");
	//		return ChoreographerList;
	//	}

	//	@GetMapping(value = "/getChoreographerById")
	//	public Choreographer getChoreographerById(@RequestParam("ChoreographerId") int ChoreographerId) {
	//
	//		Choreographer choreographer = new Choreographer();
	//		choreographer = choreographerService.getChoreographerById(ChoreographerId);
	//		System.out.println(choreographer);
	//		return choreographer;
	//	}

	@GetMapping(value="/getChByLocation")
	public List<Choreographer> getChoreographer(@RequestParam("location") String location)
	{
		List<Choreographer> list= new ArrayList<Choreographer>();
		list=choreographerService.getChoreographerByLocation(location);

		return list;
	}


	/*
	 * @PutMapping(value="/updateCount") // public void
	 * updateCount(@RequestParam("chName")String chName,HttpSession session) public
	 * void updateCount(HttpSession session) {
	 * 
	 * // System.out.println("chname"+chName); // Choreographer ch= new
	 * Choreographer(); // ch=choreographerService.getChByName(chName); // int
	 * count=ch.getIntake(); // count=count-1; // ch.setIntake(count); //
	 * Choreographer c=choreographerService.addChoreographer(ch); // return c; //
	 * System.out.println("Hellochname "+chName); String temp= (String)
	 * session.getAttribute("chname"); System.out.println("Hellochname "+temp);
	 * choreographerService.updateChCount(temp); // int
	 * val=choreographerService.updateChCount(chName); // return val; }
	 */
}
