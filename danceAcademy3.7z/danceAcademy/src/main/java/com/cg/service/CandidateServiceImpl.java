package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Candidate;
import com.cg.dao.CandidateDao;

@Service
public class CandidateServiceImpl {

	@Autowired
	CandidateDao candidateDao;
	
	public Candidate addCandidate(Candidate candidate) {
		return candidateDao.save(candidate);
	}

//	@Override
//	public boolean signUp(Candidate candidate) {
//		// TODO Auto-generated method stub
//		System.out.println("Service");
//		return iCandidateDao.signUp(candidate);
//	}

}
