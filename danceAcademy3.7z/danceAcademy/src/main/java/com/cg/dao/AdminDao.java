package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.beans.Admin;

@Repository
public interface AdminDao extends JpaRepository<Admin, Integer> {

	@Query(value = "SELECT * FROM Admin s WHERE s.admin_mail = ?1 AND s.admin_pass = ?2", nativeQuery = true)
	public Admin validateAdmin(String adminEmail, String adminPass);

	@Query(value = "SELECT * FROM Admin", nativeQuery = true)
	public List<Admin> getAllAdmin();
}