package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.beans.Choreographer;

@Repository
public interface ChoreographerDao extends JpaRepository<Choreographer, Integer> {
	@Query(value = "SELECT * FROM choreographer s WHERE s.username = ?1 AND s.password = ?2", nativeQuery = true)
	public Choreographer validateChoreographer(String username, String password);

	@Query(value = "SELECT * FROM choreographer s WHERE s.role='choreographer'", nativeQuery = true)
	public List<Choreographer> getAllChoreographer();
}
