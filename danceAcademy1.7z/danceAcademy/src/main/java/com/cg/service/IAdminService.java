package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Admin;
import com.cg.dao.AdminDao;

@Service
public class IAdminService {

	@Autowired
	AdminDao adminDao;

	public Admin addAdmin(Admin Admin) {
		return adminDao.save(Admin);
	}

	public Admin valdiateAdmin(String username, String password) {
		return adminDao.validateAdmin(username, password);
	}

	public List<Admin> getAllAdmin() {
		return adminDao.getAllAdmin();
	}

	public Admin getAdminById(int id) {
		return adminDao.getOne(id);
	}
}
